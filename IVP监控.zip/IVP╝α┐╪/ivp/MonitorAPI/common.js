function urlJump(url){
	location.href=url;
}

function getDeviceInfo(ref_path){
	var ref = ref_path; 
	var idx = ref.indexOf("?"); 
	var param = ref.substr(idx+1);
	var dev_info = param.split("&");
	idx = dev_info[0].indexOf("=");
	if(idx != -1){
		var device = dev_info[0].substr(idx+1);
		return device;
	}

	return "";
}

function getRequestInfo(ref_path, field_n){
	var ref = ref_path; 
	var idx = ref.indexOf("?"); 
	var param = ref.substr(idx+1);
	var req_info = param.split("&");
	var req_array = new Array(field_n);
	var len = field_n>req_info.length?req_info.length:field_n;

	for(var iii = 0; iii < len; iii ++){
		idx = req_info[iii].indexOf("=");
		if(idx != -1){
			req_array[iii] = req_info[iii].substr(idx+1);
		}
	}

	return req_array;
}

function isFormChanged(form) {
	var lst = form.elements;
	var tag;
	
	for(var i=0; i < lst.length; i++){
		tag = lst[i].tagName;
		if(/select/i.test(tag)){
			var opts = lst[i].options;
			var opt_flag = false;
			var sel_idx = 0;
			var def;
			for(var j = 0; j < opts.length; j++){
				opt_flag = opt_flag || (opts[j].selected != opts[j].defaultSelected);
				if(opts[j].defaultSelected){
					def = j;
				}
			}
			
			if(opt_flag && !lst.multiple){
				opt_flag = (def != lst.selectedIndex);
			}
			if(opt_flag){
				return true;
			}
		}else if(/input/i.test(tag) && /checkbox|radio/i.test(lst[i].type)){
			if(lst[i].checked != lst[i].defaultChecked){
				return true;
			}
		}else if(/input/i.test(tag) && /text/i.test(lst[i].type)){
			if(lst[i].value != lst[i].defaultValue){
				return true;
			}
  		}
	}
	
	return false;
}

function getSource(slot_num)
{
	var source;
	var source_list = "";

	$.ajax({
		url: "boardcontroller.cgi",
		data:"action=get&object=sourcelist",
		async:false,
		cache: false,
		success: function(json_txt){
			var json_obj = JSON.parse(json_txt);
			if(json_obj.Head.ErrorCode != 0){
				if(json_obj.Head.Message != ""){
					//alert("error message:"+json_obj.Head.Message);
				}
				return;
			}
			
			if(json_obj.Body.inport_num == undefined || json_obj.Body.inputs == undefined){
				return;
			} 

			for(var i = 0; i < parseInt(json_obj.Body.inport_num); i++){
				source = "";
				if(json_obj.Body.inputs[i].slotid == undefined || json_obj.Body.inputs[i].slotport == undefined){	// || json_obj.Body.Source[i].in_num < 1
					continue;
				}

if(json_obj.Body.inputs[i].slotport == "HDE_In2" || json_obj.Body.inputs[i].slotid == "Redundancy" || json_obj.Body.inputs[i].slotid == "PortMapping"){
	continue;
}

				var slot_num_tmp;
				if (json_obj.Body.inputs[i].slotid != "alcm") {
					if(json_obj.Body.inputs[i].slotid.substring("slot".length) == "" || (slot_num_tmp = parseInt(json_obj.Body.inputs[i].slotid.substring("slot".length))) == undefined){
						if (json_obj.Body.inputs[i].slotid == "ci") {
							slot_num_tmp = 6;
						} else {
							continue;
						}
					}
					if(slot_num == slot_num_tmp){
						continue;
					}

					source_list += json_obj.Body.inputs[i].slotid+","+json_obj.Body.inputs[i].slotport+","+get_slot_type(slot_num_tmp, json_obj.Body.inputs[i].type)+"-"+json_obj.Body.inputs[i].slotport+";";
				} else {
					source_list += json_obj.Body.inputs[i].slotid+","+json_obj.Body.inputs[i].slotport+",ALC-"+json_obj.Body.inputs[i].slotport+";";
				}
			}

			if(source_list != ""){
				source_list = source_list.substring(0, source_list.length-1);
			}
		}
	});

	return source_list;
}

function getSourceToSelect(select_name, slot_num)
{
	$.ajax({
		url: "boardcontroller.cgi",
		data:"action=get&object=sourcelist",
		async:false,
		cache: false,
		success: function(json_txt){
			var json_obj = JSON.parse(json_txt);
			if(json_obj.Head.ErrorCode != 0){
				if(json_obj.Head.Message != ""){
					//alert("error message:"+json_obj.Head.Message);
				}
				return;
			}

			if(json_obj.Body.inport_num == undefined || json_obj.Body.inputs == undefined){
				return;
			}

			for(var i = 0; i < parseInt(json_obj.Body.inport_num); i++){
				source = "";
				if(json_obj.Body.inputs[i].slotid == undefined || json_obj.Body.inputs[i].slotport == undefined){	// || json_obj.Body.Source[i].in_num < 1
					continue;
				}

if(json_obj.Body.inputs[i].slotport == "HDE_In2" || json_obj.Body.inputs[i].slotid == "Redundancy" || json_obj.Body.inputs[i].slotid == "PortMapping"){
	continue;
}

				var slot_num_tmp;
				if((slot_num_tmp = parseInt(json_obj.Body.inputs[i].slotid.substring("slot".length))) == undefined){
					continue;
				}
				/*if(slot_num == slot_num_tmp){
					continue;
				}*/

				var value = json_obj.Body.inputs[i].slotid+","+json_obj.Body.inputs[i].slotport;
				var text;
				if(json_obj.Body.inputs[i].slotid == "mux"){
					if(json_obj.Body.inputs[i].slotport == "MUX5_Out" || json_obj.Body.inputs[i].slotport == "MUX4_Out"){
						continue;
					}
					text = "Mux-"+json_obj.Body.inputs[i].slotport;
				}else if(json_obj.Body.inputs[i].slotid == "ci" || json_obj.Body.inputs[i].slotid == "slot6"){
					text = "FR-"+json_obj.Body.inputs[i].slotport;
				}else if(json_obj.Body.inputs[i].slotid == "alcm"){
					text = "ALC-"+json_obj.Body.inputs[i].slotport;
				}else{
					text = get_slot_type(slot_num_tmp, json_obj.Body.inputs[i].type)+"-"+json_obj.Body.inputs[i].slotport;
				}
				$("select[name='"+select_name+"']").append("<option value='"+value+"'>"+text+"</option>");
			}
		}
	});
}

function getSourceRouter(select_name, slot_num, chan_id)
{
	$.ajax({
		url: "boardcontroller.cgi",
		data:"action=get&object=router&slotid="+slot_num+"&slotport="+chan_id,
		async:false,
		cache: false,
		success: function(json_txt){
			var json_obj = JSON.parse(json_txt);
			if(json_obj.Head.ErrorCode != 0){
				if(json_obj.Head.Message != ""){
					//alert("error message:"+json_obj.Head.Message);
				}
				return;
			}

			if(parseInt(json_obj.Body.Route_num) < 1 || json_obj.Body.Route_records == undefined){
				return;
			}

			var src_id = json_obj.Body.Route_records[0].src_id;
			var src_port = json_obj.Body.Route_records[0].src_port;

			$("select[name='"+select_name+"'] option[value='"+src_id+","+src_port+"']").prop("selected", true);
		}
	});
}

function getServiceList(slot_id, chan_id)
{
	var service_json= getServiceListJSON(slot_id, chan_id);
	var service_list = "";

	if (!service_json) {
		return "";
	}

	for(var i = 0; i < parseInt(service_json.ProgNum); i++){
		service_list += service_json.Channel[i].ServID+",";
		service_list += service_json.Channel[i].PcrPID+",";
		service_list += service_json.Channel[i].PmtPID+",";
		service_list += service_json.Channel[i].VideoPID+",";		/* 3 */
		service_list += service_json.Channel[i].VideoType+",";
		/*if(service_json.Channel[i].Scramb == "0x1"){
			service_list += "$";
		}*/
		service_list += service_json.Channel[i].ChannelName+",";	/* 5 */
		service_list += service_json.Channel[i].ProviderName+",";
		service_list += service_json.Channel[i].AudioNum+",";	/* 7 */
		service_list += service_json.Channel[i].AudioPID0+",";	/* 8 */
		service_list += service_json.Channel[i].AudioType0;		/* 9 */
		if(parseInt(service_json.Channel[i].AudioNum) > 1){
			service_list += ","+service_json.Channel[i].AudioPID1+",";	/* 10 */
			service_list += service_json.Channel[i].AudioType1;		/* 11 */
		}
		if(parseInt(service_json.Channel[i].AudioNum) > 2){
			service_list += ","+service_json.Channel[i].AudioPID2+",";
			service_list += service_json.Channel[i].AudioType2;
		}
		if(parseInt(service_json.Channel[i].AudioNum) > 3){
			service_list += ","+service_json.Channel[i].AudioPID3+",";	/* 14 */
			service_list += service_json.Channel[i].AudioType3;		/* 15 */
		}
		service_list += ";";
	}

	if (service_list != "") {
		service_list = service_list.substr(0, service_list.length-1);
	}

	return service_list;
}

function getServiceListJSON(slot_id, chan_id)
{
	var service_json= "";

	$.ajax({
		url: "boardcontroller.cgi",
		data:"action=get&object=serverlist&slotid="+slot_id+"&slotport="+chan_id,
		async:false,
		cache: false,
		success: function(json_txt){
			var json_obj = JSON.parse(json_txt);
			if(json_obj.Head.ErrorCode != 0 || !json_obj.Body){
				if(json_obj.Head.Message != ""){
					//alert("error message:"+json_obj.Head.Message);
				}
				return "";
			}
			
			service_json = json_obj.Body;
		}
	});

	return service_json;
}

function streamAudioTypeToEnum(format)
{
	var type = "FFFF";

	if (!format) return type;

	switch(format.toLowerCase())
	{
		case "mpeg1":
			type = "3";
			break;
		case "mpeg2":
			type = "4";
			break;
		case "aac":	//mpeg2 aac
			type = "F";
			break;
		case "heaac":	//mpeg 4 latm aac,heaac v1,aac+,eaac
			type = "11";
			break;
		case "mepg4":	//mpeg4 generic
			type="12"
			break;
		case "ac3":	//a52/ac3
			type = "81";
			break;
		case "dra":
			type = "97";
			break;
		case "dts":
			type = "82";
			break;
		case "lpcm":
			type = "83";
			break;
		case "sdds":
			type = "84";
			break;
		//case 85: ATSC program id
		case "dts_hd":
			type = "86";
			break;
		case "ac3+":	//????
			type="87";
			break;
		case "a52v/ac3":
			type = "91";
			break;
		case "dvd/spu vls":
			type = "92";
			break;
		case "sdds":
			type = "94";
			break;
		case "mscodec":
			type = "A0";
			break;
		default:
			type = "FFFF";
	}

	return type;
}

function streamAudioType(format)
{
	var type = "Unknown";

	if (!format) return type;

	switch(format)
	{
		case 0x03:
			type = "mpeg1";
			break;
		case 0x04:
			type = "mpeg2";
			break;
		case 0x0F:	//mpeg2 aac
			type = "aac";
			break;
		case 0x11:	//mpeg 4 latm aac,heaac v1,aac+,eaac
			type = "heaac";
			break;
		case 0x12:	//mpeg4 generic
			type="mepg4";
			break;
		case 0x81:	//a52/ac3
			type = "ac3";
			break;
		case 0x97:
			type = "dra";
			break;
		case 0x82:
			type = "dts";
			break;
		case 0x83:
			type = "lpcm";
			break;
		case 0x84:
			type = "sdds";
			break;
		//case 85: ATSC program id
		case 0x86:
			type = "dts_hd";
			break;
		case 0x87:	//????
			type="ac3+";
			break;
		case 0x91:
			type = "a52v/ac3";
			break;
		case 0x92:
			type = "dvd/spu vls";
			break;
		case 0x94:
			type = "sdds";
			break;
		case 0xA0:
			type = "mscodec";
			break;
		default:
			type = "Unknown";
	}

	return type.toUpperCase();
}

function streamTypeToEnum(format)
{
	var type;

	switch(format.toLowerCase())
	{
		case "mpeg1":
			type = "1";
			break;
		case "mpeg2":
			type = "2";
			break;
		case "h.263":
			type = "1A";		//FIXME:correct it
			break;
		case "h.264":
			type = "1B";
			break;
		case "avs+":
			type="42";
			break;
		case "vc1":
			type="EA";
			break;
		case "vc1_sm":
			type="EB";		//FIXME:correct it!!!
			break;
		default:
			type = "FFFF";
	}

	return type.toUpperCase();
}

function streamVideoType(format)
{
	var type = "Unknown";

        if (!format) return type;

	switch(format)
	{
		case 0x01:
			type = "mpeg1";
			break;
		case 0x02:
			type = "mpeg2";
			break;
		case 0x1A:
			type = "h.263";		//FIXME:correct it
			break;
		case 0x1B:
			type = "h.264";
			break;
		case 0x42:
			type="avs+";
			break;
		case 0xEA:
			type="vc1";
			break;
		case 0xEB:
			type="vc1_sm";		//FIXME:correct it!!!
			break;
		default:
			type = "Unknown";
	}

	return type.toUpperCase();
}

function get_slot(slot_id)
{
	var slot_info;

	switch(slot_id){
		case 0:
		case 1:
		case 2:
			slot_info = "L"+(slot_id+1);
			break;
		case 3:
		case 4:
		case 5:
			slot_info = "U"+(slot_id+1-3);
			break;
		case 6:
			slot_info = "FR";
			break;
		case 7:
			slot_info = "Mux";
			break;
		case 8:
			slot_info = "Main";
			break;
		default:
			slot_info = "";
	}

	return slot_info;
}

function get_slot_type(slot_id, type)
{
	var slot_info;

	switch(slot_id){
		case 0:
		case 1:
		case 2:
			slot_info = "L"+(slot_id+1);
			break;
		case 3:
		case 4:
		case 5:
			slot_info = "U"+(slot_id+1-3);
			break;
		case 6:
			slot_info = "FR";
			break;
		case 7:
			slot_info = "Mux";
			break;
		case 8:
			slot_info = "Main";
			break;
		default:
			slot_info = "";
	}

        var board_type = JSON.parse(get_devic_info(type));
        if (board_type.dev_info.name) {
          slot_info = slot_info+'('+board_type.dev_info.name+')';
        }

	return slot_info;
}

function enumToStreamType(type)
{
	var format;

	switch(type)
	{
		case 0x01:	//video
			format = "MPEG1";
			break;
		case 0x02:	//video
			format = "MPEG2";
			break;
		case 0x03:	//audio
			format = "MPEG1";
			break;
		case 0x04:	//audio
			format = "MPEG2";
			break;
		case 0x97:
			format = "DRA";
			break;
		case 0x0f:	//mpeg2 aac
			format = "AAC";
			break;
		case 0x11:	//mepg4 aac
			format = "HEAAC";
			break;
		case 0x12:	//mpeg4 generic
			format = "MPEG4";
			break;
		case 0x1B:
			format = "H.264";
			break;
		case 0x42:
			format="AVS+";
			break;
		case 0x81:
			format = "AC3";
			break;
		case 0x82:
			format = "DTS";
			break;
		case 0x83:
			format = "LPCM";
			break;
		case 0x84:
			format = "SDDS";
			break;
		case 0x87:
			format ="AC3+";
			break;
		case 0x96:
			format = "DTS_HD";
			break;
		case 0xEA:
			format = "VC1";
			break;
		case 0xEB:
			format = "VC1_SM";
			break;
		default:
			format = "Unknown";
			break;
	}

	return format;
}

function get_enc_status(e_stat)
{
	var status;

	switch(e_stat){
		case 0:
			status = "Booting";
			break;
		case 2:
			status = "Encoding";
			break;
		default:
			status = "Error Code:"+e_stat;
			break;
	}

	return status;
}

function get_enc_fmt(e_fmt)
{
		var fmt;
	
		switch(e_fmt){
			case 0x00:
				fmt = "1080i59.94";
				break;
			case 0x1:
				fmt = "1080i60";
				break;
			case 0x2:
				fmt = "1080i50";
				break;
			case 0x10:
				fmt = "720p59.94";
				break;
			case 0x11:
				fmt = "720p60";
				break;
			case 0x12:
				fmt = "720p50";
				break;
			case 0x20:
				fmt = "480i59.94";
				break;
			case 0x32:
				fmt = "576i50";
				break;
			case 0x44:
				fmt = "1080p29.97";
				break;
			case 0x45:
				fmt = "1080p30";
				break;
			case 0x46:
				fmt = "1080p25";
				break;
			case 0xFF:
			default:
				fmt = "Unlocked";
		}
		
		return fmt;
}

function get_sdenc_status(e_stat)
{
	var status;

	switch (e_stat){
		case 0x01:
			status = "Idle";
			break;
		case 0x02:
			status = "Encoding";
			break;
		case 0x03:
			status = "Stopped";
			break;
		case 0x04:
			status = "Recoverable error";
			break;
		case 0x05:
			status = "Unrecoverable error";
			break;
		case 0x00:
		default:
			status = "Uninitialized";
	}

	return status;
}

function get_sdenc_fmt(e_fmt)
{
	var fmt;

	switch(e_fmt){
		case 0x01:
			fmt = "CVBS-576i50";
			break;
		case 0x02:
			fmt = "CVBS-480i59.94";
			break;
		case 0x03:
			fmt = "CVBS-480i60";
			break;
		case 0x04:
			fmt = "SDI-576i50";
			break;
		case 0x05:
			fmt = "SDI -480i59.94";
			break;
		case 0x06:
			fmt = "SDI -480i60";
			break;
		case 0xFF:
		default:
			fmt = "No input";
	}
	
	return fmt;
}

function set_json_head(err_code, err_msg)
{
	return '\"Head\": {\"ErrorCode\":\"'+err_code+'\",\"Message\":\"'+err_msg+'"}';
}

function get_json_value(jason_obj, key)
{
	var value = "";

	if(typeof jason_obj !== "object"){
		return value;
	}

	$.each(jason_obj, function (key_i, value_i) {
		if(key_i == key){
			value = value_i;
			return false;
		}
	});

	return value;
}

/*
 * param:
 *	type: device hard
 *	name:device name
 *	io_type:input/output type.
 *		0:input device
 *		1:output device
 *		2:input&output device
 *	in_num:input channels num
 *	out_num:output channels num
 * 
*/
function get_devic_info(devide_type)
{
	var dev_info;
	var name;
	var io_type;
	var in_num;
	var out_num;

	switch (devide_type){
		case 0x00:
			name = "CAM";
			io_type = 0;
			in_num = 0;
			out_num = 4;
			break;
		case 0x01:
			name = "ASI";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x02:
			name = "ASI";
			io_type = 2;
			in_num = 3;
			out_num = 1;
			break;
		case 0x03:
			name = "ASI";
			io_type = 2;
			in_num = 2;
			out_num = 2;
			break;
		case 0x04:
			name = "ASI";
			io_type = 2;
			in_num = 1;
			out_num = 3;
			break;
		case 0x05:
			name = "ASI";
			io_type = 2;
			in_num = 0;
			out_num = 3;
			break;
		case 0x06:
			name = "IP_DEC";
			io_type = 2;
			in_num = 2;
			out_num = 16;
			break;
		case 0x19:	//sde 1v
		case 0x07:
			name = "DSDE";
			io_type = 1;
			in_num = 2;
			out_num = 0;
			break;
		case 0x08:
			name = "ASDE";
			io_type = 1;
			in_num = 2;
			out_num = 0;
			break;
		case 0x09:
			name = "HDE";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x0A:
			name = "HDE";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x0B:
			name = "HDE";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x1A:	//lnb-biss
		case 0x1D:	//lnb s2
		case 0x0C:
			name = "Tuner";
			io_type = 0;
			in_num = 2;
			out_num = 0;
			break;
		case 0x0D:
			name = "DDO";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x0E:
			name = "ADO";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x18:	//MV
			name = "MV";
			io_type = 0;
			in_num = 0;
			out_num = 16;
			break;
		case 0x0F:
			name = "MDO";
			io_type = 0;
			in_num = 0;
			out_num = 16;
			break;
		case 0x10:
			name = "TRM";
			io_type = 0;
			in_num = 0;
			out_num = 0;
			break;
		case 0x11:
			name = "IPM_ENC";
			io_type = 0;
			in_num = 0;
			out_num = 28;
			break;
		case 0x13:
			name = "IP/ASI_ENC";
			io_type = 0;
			in_num = 0;
			out_num = 28;
			break;
		case 0x14:
			name = "IP/ASI_DEC";
			io_type = 0;
			in_num = 0;
			out_num = 28;
			break;
		case 0x28:
			name = "IP/ASI";
			io_type = 0;
			in_num = 0;
			out_num = 28;
			break;
		case 0x15:
			name = "HDDO";
			io_type = 0;
			in_num = 0;
			out_num = 1;
			break;
		case 0x16:
			name = "Tuner-T";
			io_type = 0;
			in_num = 2;
			out_num = 0;
			break;
		case 0x1B:
			name = "ALC";
			io_type = 0;
			in_num = 1;
			out_num = 1;
			break;
		case 0x1C:
			name = "SMIP";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x23:
			name = "SMIP";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x1E:
			name = "AVSDec";
			io_type = 1;
			in_num = 0;
			out_num = 1;
			break;
		case 0x1F:
			name = "AVSTran";
			io_type = 0;
			in_num = 1;
			out_num = 1;
			break;
		case 0x22:
			name = "MHDE3";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x24:
			name = "MTRA3";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x25:
			name = "MTRA4";
			io_type = 0;
			in_num = 4;
			out_num = 0;
			break;
		case 0x26:
			name = "MHDE1";
			io_type = 0;
			in_num = 1;
			out_num = 1;
			break;
		case 0x27:
			name = "MHDE2";
			io_type = 0;
			in_num = 2;
			out_num = 0;
			break;
		default:
			name = "N/A";
			io_type = 0;
			in_num = 0;
			out_num = 0;
	}

	dev_info = '{"dev_info":{"type":'+devide_type+',"name":"'+name+'", "io_type":'+io_type+', "in_num":'+in_num+', "out_num":'+out_num+'}}';

	return dev_info;
}

function set_cookie(mins)
{
	var set_min;
	var expire_time = new Date();
	if(mins == "0"){
		set_min = 10;
	}else{
		set_min = parseInt(mins);
	}
	expire_time.setTime(expire_time.getTime() + set_min * 60 * 1000);
	$.cookie('ivp_cookie', 'cookie_me', { expires: expire_time, path: '/' });
	return ;
}

function valid_cookie()
{
	if($.cookie("ivp_cookie") == "cookie_me"){
		return true;
	}else{
		return false;
	}
}

function clear_cookie()
{
	$.removeCookie('ivp_cookie', { path: '/' });
}

function jump2Top()
{
	//if (top.location !== self.location){
//		top.location = "../login.html";
	//}
}

function tool_tip_msg(o_id, o_container, place, msg, err)
{	
	$(o_id).popover({
		html:true,
		title:"Tip<button type='button' class='close' onclick='$(&#39"+o_id+"&#39).popover(&#39destroy&#39);' aria-hidden='true'>&times;</button>",
		trigger:"manual",
		container:o_container,
		toggle:"popover",
		placement:place,
		//delay:{show:200, hide:200},
		content:"<p class='text-danger'><b>"+msg+"</b></p>",
	}).popover("show");

	if(msg.toLowerCase().substr(0, 6) == "succes"){
		setTimeout(function(){$(o_id).popover("destroy");}, 2*1000);
	}
}

function ivp_tool_tip_msg(msg)
{
	/*var tip_msg = "<span>"+msg+"<span style='float:right;'><a onclick='too_tip_close($(&#39#ivp_tool_tip&#39))' href='javascript:void(0);' title='Close the tip'>X</a>&nbsp;&nbsp;</span></span>"
	$("#ivp_tool_tip").html(tip_msg);
	$("#ivp_tool_tip").css("display", "block");
	$("#ivp_tool_tip").attr("title", 'Double-click the mouse to close the tip');
	$("#ivp_tool_tip").dblclick(function(evt){
		too_tip_close($("#ivp_tool_tip"));
	});*/

	//$(obj).attr("title", $(obj).attr("title").append("Double-click the mouse to close the tip"));
	tool_tip_msg("#ivp_tool_tip", "body", "top", msg);

	/*$(".popover").dblclick(function(){
		$(obj).popover('hide');
	});*/
}

